#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int ismatch (char *array1, char *array2)
{
    char *p1 = array1;
    char *p2 = array2;

    while(*p1 != '\0'){ // null kontrolü 
        if((*p2 == '\0') || (*p2 > *p1) || (*p1 > *p2))
            return 1;
        p1++;
        p2++;
    }
    if (*p2 != '\0') return 1;

    return 0;
}

int main(){
    FILE *okunan_dosya, *yazma_dosya;
    okunan_dosya = fopen("code.psi.txt", "r");
    yazma_dosya = fopen("code.lex.txt", "w");

    char keywords[18][20]={"break","case","char","if","else",
    "enum","float","while","long","record","return","static","continue","do","for","int","goto","const"};
    char kelime[30];
    char strings[100];

    int i = 0, j = 0, k = 0, m = 0;
    int kontrol = 1;
    int identifier_len = 0, int_len = 0;

    char sth = getc(okunan_dosya);
    if(sth == -1)
    {
        printf("File not found!");
        return 1;
    }
    while(!feof(okunan_dosya)){
        if(sth == 32 || (8 < sth && sth < 14)){ //Bosluk karakterleri için, ascii degerleri ile kontrol
            sth = getc(okunan_dosya);
        }
        //identifier ve keywordler için
        sth=toupper(sth);
        if(64 < sth && sth < 91 ){ //Alinan karakter buyuk harf
            i = 0;
            j = 0;
            identifier_len = 0;
            kontrol = 1; //keyword mü, identifier mi kontrolü için
            while((96 < sth && sth <123) || (64 < sth && sth < 91) || (47 < sth && sth < 58)|| sth == 95){ //Buyuk kucuk harfler, alt çizgi ve rakamlar
                if(i > 20){
                    printf("Identifier names should be smaller than 20 characters!");
                    return 1;
                }
                if((47 < sth && sth < 58)|| sth == 95){ //Eger alınan karakter sayi ya da _ ise identifier
                    kontrol = 0;
                }
                kelime[i] = sth;
                sth = getc(okunan_dosya);
                i++;
            }
            kelime[i] = '\0'; //Kelimenin sonuna null karakter eklendi
            identifier_len = i;
            if(kontrol == 1){ //Karakterlerin tamamı harf ise keyword mu degil mi kontrolu yapılır
                while(j < 18){
                    if(ismatch(kelime, keywords[j]) == 0){ // kontrol edilen, keywordlerin bulunduğu dizinin elemanları ile aynı mı,değil mi diye kontrol
                        fputs("Keyword(", yazma_dosya);
                        kontrol = 1;
                        break;
                    }
                    else{ //identifier durumu
                        kontrol = 0;
                    }
                    j++;
                }
            }
            if(kontrol == 0){ //Karakterlerin içinde sayi ve/veya _ bulunuyorsa, veyasayı ve/veya _ bulunuyorsa ve bir keywordle eşleşmediyse
                fputs("Identifier(", yazma_dosya);
            }
            j = 0;
            while(j < identifier_len){
                fputc(tolower(kelime[j]), yazma_dosya);
                j++;
            }
            fputs(")\n", yazma_dosya);
        }
        //operator blokları
        if(sth == 43){ //  + ya da ++ durumu kontrolü
            sth = getc(okunan_dosya);
            if(sth == 43){
                fputs("Operator(++)\n", yazma_dosya);
            }
            else{
                fputs("Operator(+)\n", yazma_dosya);
                continue;
            }
        }
        if(sth == 45){ // - ya da -- durumu kontrolü
            sth = getc(okunan_dosya);
            if(sth == 45){
                fputs("Operator(--)\n", yazma_dosya);
            }
            else{
                fputs("Operator(-)\n", yazma_dosya);
                continue;
            }
        }
        if(sth == 42){
          fputs("Operator(*)\n", yazma_dosya);
        }
        if(sth == 58){
            sth = getc(okunan_dosya);
            if(sth == 61){
                fputs("Operator(:=)\n",yazma_dosya);
            }else{
                printf("Undefined input : character!");
                return 1;
            }
        }
        if(sth == 40){ //alinan karakter ( isareti
            sth = getc(okunan_dosya);
            if(sth == 42){ //* kontrolü
                sth = getc(okunan_dosya);
                while(sth!=42){
                    sth=getc(okunan_dosya);
                }
                    if(sth == 42){ //yıldız geldiyse,yıldızdan sonraki karakter ) ise yorum sonu demektir
                            sth = getc(okunan_dosya);
                        if(sth == 41) //İkinci yildizdan sonra ) geldi mi
                               sth=getc(okunan_dosya);
                               if(sth==EOF){
                                   break;
                               }
                        } 
                    if(sth == EOF){
                        printf("Error");
                        return 1;
                    }
                }
            
            else{
                fputs("Operator(/)\n", yazma_dosya);
                continue;
            }
        }
        //string blogu
        if(sth == 34){ //Alınan karakter çift tırnak
            sth = getc(okunan_dosya);
            strings[k] = sth;
            k++;
            while(sth != 34 && sth != EOF){
                sth = getc(okunan_dosya);
                strings[k] = sth;
                k++;
            }
            strings[k] = '\0'; //String sonuna null karakteri eklendi
            if(sth == 34){ //Tırnak kapanırsa
                fputs("StrConst(", yazma_dosya);
                while(m < (strlen(strings)-1)){
                    fputc(strings[m], yazma_dosya);
                    m++;
                }
                fputs(")\n", yazma_dosya);
            }
            else if(sth == EOF){ //Tırnak kapanmadan dosyanın bitmesi durumu
                printf("Missing terminating \" character!");
                return 1;
            }
        }
        //Integer blogu
        if(47 < sth && sth < 58){ //rakamlarin ascii değerleri ile kontrol
            fputs("IntConst(", yazma_dosya);
            while (47 < sth && sth < 58){
                if(int_len > 10){
                    printf("Integers can't be longer than 10 characters!");
                    return 1;
                }
                fputc(sth, yazma_dosya);
                sth = getc(okunan_dosya);
                int_len++;
            }
            fputs(")\n", yazma_dosya);
            int_len = 0;
            continue;
        }
        if(sth == 59){ // ; karakteri kontrolü
            fputs("EndOfLine\n",yazma_dosya);
        }
        //Parantez karakterleri blokları
        if(sth == 40){
            fputs("LeftPar\n", yazma_dosya);
        }
        if(sth == 41){
           fputs("RightPar\n", yazma_dosya); 
        } 
        if(sth == 91){
           fputs("LeftSquareBracket\n", yazma_dosya);
        }
        if(sth == 93){
           fputs("RightSquareBracket\n", yazma_dosya);
        }
        if(sth == 123)
        {
           fputs("LeftCurlyBracket\n", yazma_dosya);
        }
        if(sth == 125){
           fputs("RightCurlyBracket\n", yazma_dosya);
        }
        sth = getc(okunan_dosya);
    }
    fclose(okunan_dosya);
    fclose(yazma_dosya);
    fflush(stdin);
    return 0;
    
}